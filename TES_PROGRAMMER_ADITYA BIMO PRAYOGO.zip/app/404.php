<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>404</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css" />
    <style>
    @font-face {
  font-family: "stranger";
  src: url("https://s3-us-west-2.amazonaws.com/s.cdpn.io/455279/stranger.ttf") format("truetype");
}
html {
  background: linear-gradient(0deg, #050514, #30336b);
  overflow: hidden;
  height: 100%;
}
html body {
  margin: 0;
}

.patch {
  position: absolute;
  bottom: 0;
  height: 10vh;
  width: 3vw;
  background-color: black;
  z-index: 2;
}
.patch:nth-child(odd) {
  background-color: rgba(0, 0, 0, 0.9);
  z-index: 0;
}

.bottompatch {
  position: absolute;
  background-color: red;
  bottom: 0;
  left: 0;
}

.gravestones .cross {
  position: absolute;
  height: 28vh;
  width: 1.8vh;
  background-color: black;
  bottom: 0;
  z-index: 1;
}
.gravestones .cross:after {
  content: "";
  position: absolute;
  background-color: inherit;
  height: 1.8vh;
  width: 10vh;
  top: 5vh;
  left: 50%;
  transform: translateX(-50%);
}
.gravestones .cross:nth-child(1) {
  left: 20%;
}
.gravestones .cross:nth-child(2) {
  left: 70%;
  bottom: -4vh;
}
.gravestones .cross:nth-child(3) {
  left: 90%;
}

.msg {
  display: none;
  color: black;
  font-size: 6.2vh;
  font-family: "stranger", arial;
  position: absolute;
  bottom: 14vh;
  left: 50%;
  transform: translateX(-50%);
  z-index: 2;
}

.crypt {
  position: absolute;
  bottom: 0;
  left: 50%;
  transform: translateX(-50%);
  width: 38vh;
  height: 40vh;
}
.crypt .roof {
  height: 10vh;
  width: 100%;
  background-color: black;
  -webkit-clip-path: polygon(21% 0%, 79% 0%, 100% 100%, 0% 100%);
  clip-path: polygon(21% 0%, 79% 14%, 100% 100%, 0% 100%);
}
.crypt .body {
  width: 86%;
  height: 100%;
  background-color: black;
  margin: -1vh auto 0 auto;
}
.crypt .body .door {
  position: absolute;
  bottom: 0;
  left: 50%;
  transform: translateX(-50%) rotateZ(-3deg);
  width: 20%;
  height: 45%;
  border-top-right-radius: 100%;
  border-top-left-radius: 100%;
  background-color: black;
}

.fog {
  width: 40vh;
  height: 20vh;
  border-top-right-radius: 100%;
  border-top-left-radius: 100%;
  background-color: rgba(255, 255, 255, 0.2);
  position: absolute;
  bottom: 0;
  z-index: 1;
  animation-name: fog;
  animation-iteration-count: infinite;
  animation-duration: 80s;
}

.moon {
  position: absolute;
  top: 8vh;
  right: 18vh;
  height: 20vh;
  width: 20vh;
  border-radius: 20vh;
  box-shadow: inset -2vh 0 0 #dfe6e9;
  transform: rotateZ(32deg);
}

.title {
  height: 65vh;
  margin: 0;
  position: absolute;
  left: 49%;
  bottom: -90vh;
  opacity: 0.1;
  transition: filter 3s;
  transform: translate(-50%, -50%) rotateZ(-4deg);
  font-family: "stranger", arial;
  font-size: 60vh;
  color: #dfe6e9;
  z-index: 1;
}

.life {
  opacity: 1;
  transition: opacity 4s;
  animation-name: float;
  animation-iteration-count: infinite;
  animation-duration: 5s;
}

.star {
  height: 1px;
  width: 1px;
  background-color: white;
  position: absolute;
  z-index: 0;
}

@keyframes fog {
  0% {
    filter: blur(10vh);
    left: -9vw;
    transform: rotateZ(19deg);
  }
  50% {
    filter: blur(13vh);
    left: 109vw;
  }
  100% {
    filter: blur(10vh);
    left: 9vw;
    transform: rotateZ(-19deg);
  }
}
@keyframes float {
  0% {
    top: 45%;
  }
  50% {
    top: 46%;
  }
  100% {
    top: 45%;
  }
}

    </style>
</head>

<body>
<main>
 <div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='star'></div>
<div class='title'>404</div>
<div class='gravestones'>
  <div class='cross'></div>
  <div class='cross'></div>
  <div class='cross'></div>
</div>
<div class='bottompatch'>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
  <div class='patch'></div>
</div>
<div class='msg'>
  This page doesn't exist.
</div>
<div class='crypt'>
  <div class='roof'></div>
  <div class='body'>
    <div class='door'></div>
  </div>
</div>
<div class='fog'></div>
<div class='moon'></div>

</main>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.0/jquery.min.js" integrity="sha512-3gJwYpMe3QewGELv8k/BX9vcqhryRdzRMxVfq6ngyWXwo03GFEzjsUm8Q7RZcHPHksttq7/GFoxjCVUjkjvPdw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script>
$(".patch").each((i) => {
  let b = i + 1;
  let rX = Math.floor(Math.random() * 50);
  let rY = Math.floor(Math.random() * 100);
  let rH = Math.floor(Math.random() * 10) + 15;
  $(".patch:nth-child(" + b + ")").css({
    left: i - 1 + "vw",
    height: rH + "vh",
    "-webkit-clip-path": "polygon(" + rX + "% " + rX + "%, 0% 100%, 100% 100%)",
    "clip-path": "polygon(" + rX + "% " + rX + "%, 0% 100%, 100% 100%)"
  });
});

$(".cross").each((i) => {
  let b = i + 1;
  let rR =
    Math.floor(Math.random() * 15) *
    Math.cos(Math.PI * Math.round(Math.random()));
  $(".cross:nth-child(" + b + ")").css({
    transform: "rotateZ(" + rR + "deg)"
  });
});

$(".star").each((i) => {
  $(".star:nth-child(" + i + ")").css({
    top: Math.random() * $(document).height() - $(document).height() / 4,
    left: Math.random() * $(document).width()
  });
});

init = () => {
  $(".crypt").css({
    transform:
      "translateX(-50%) rotateZ(" +
      Math.floor(Math.random() * 5) *
        Math.cos(Math.PI * Math.round(Math.random())) +
      "deg)"
  });
  $(".title").animate(
    {
      top: "45%"
    },
    5000,
    () => {
      $(".title").addClass("life");
      $(".msg").fadeIn(1000);
    }
  );
};
init();

</script>
</body>

</html>