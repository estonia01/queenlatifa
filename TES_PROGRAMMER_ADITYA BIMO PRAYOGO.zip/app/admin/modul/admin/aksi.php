<?php	
use \Gumlet\ImageResize;
	// Update modul

    if (  $act == 'add' ) {

        $edit = $db->connection( "SELECT username FROM tb_user WHERE username = '$_POST[username]' " );
        $tedit = $edit->fetch( PDO::FETCH_ASSOC );
        if(!empty($tedit['username'])){
            echo "<script>alert('username telah terpakai'); window.location(history.back(-1))</script>";
            exit;
        }
        // Upload Image
        $pass     = md5($_POST['password']);
        try {
            $datas = array(
                'nama_lengkap' 	=> $_POST["nama_lengkap"],
                'username' 		=> $_POST["username"],
                'password' 		=> $pass,
            );

            $db->insert("tb_user", $datas);

            echo "<script>alert('Data $hal berhasil ditambah'); window.location = '$hal'</script>";

        } catch( PDOException $e ) {
            echo "<script>alert('$hal Gagal diedit!'); window.location = '$hal'</script>";
        }

    }

	elseif ($act=='update'){

		$jdl2 				 = substr( $_POST['username'], 0, 80 );
        $tipe_file   	 	 = $_FILES['lopoFile']['type'];
        $nama_file   		 = $_FILES['lopoFile']['name'];
        $ukuran   			 = $_FILES['lopoFile']['size'];
        $tipe_file2   	 	 = seo2( $tipe_file );
        $judul_seo 		 	 = seo( $_POST['username'] );
        $acak           	 = rand( 00, 99 );
        $nama_file_unik 	 = $judul_seo.'-'.$acak.'.'.$tipe_file2;

		
		$username = $_POST['username'];
		
		if($_POST['password_lama']!=$_POST['password']){
			$pass     = md5($_POST['password']);
		}else{
			$pass     = $_POST['password_lama'];
		}


		if ( !empty( $nama_file ) ) {

            if ( ( $ukuran == 0 ) OR ( $ukuran == 02 ) OR ( $ukuran>9060817 ) ) {
                echo "<script>window.alert('Gagal Upload Gambar, ukuran gambar lebih dari 2 MB !'); window.location(history.back(-1))</script>";
            } else {
                $edit = $db->connection( "SELECT gambar FROM tb_user WHERE id = $_POST[id] " );
                $tedit = $edit->fetch( PDO::FETCH_ASSOC );
                unlink( "images/member/$tedit[gambar]" );
                unlink( "images/member/small/$tedit[gambar]" );

                // Upload Image
                $res = lopoUpload( $judul_seo.'-'.$acak, 'member' );
                if ( $res == true ) {
                    try {

                        $datas = array(
                            'nama_lengkap' 	=> $_POST["nama_lengkap"],
                            'judul_seo'     => seo($_POST["nama_lengkap"]),
							'email' 		=> $_POST["email"],
							'no_telp' 		=> $_POST["no_telp"] ,
							'motto' 		=> $_POST["motto"] ,
							'username' 		=> $username,
							'password' 		=> $pass,
                            'gambar' 		=> $nama_file_unik,
                        );

                        $db->update("tb_user", $datas , "id = '$_POST[id]' ");

                        $pathToImage = 'images/member/'.$nama_file_unik;
                        $pathSmall   = 'images/member/small/'.$nama_file_unik;
						lopoCompress( 'member', $pathToImage, $tipe_file2, 0 );
                		lopoCompress( 'member/small', $pathToImage, $tipe_file2, 0 );
                        
                        $image = new ImageResize($pathSmall);
                        $image->resizeToHeight(200);
                        $image->save($pathSmall);

                        $image2 = new ImageResize($pathToImage);
                        $image2->resizeToHeight(500);
                        $image2->save($pathToImage);

                        echo "<script>alert('Data tb_user berhasil diedit'); window.location = 'logout'</script>";
                    } catch( PDOException $e ) {
                        echo "<script>alert('$hal Gagal diedit!'); window.location(history.back(-1))</script>";
                    }
                } else {
                    echo "<script>alert('Something error with this image'); window.location(history.back(-1))</script>";
                }

            }
		}else{
			$datas = array(
                'nama_lengkap' => $_POST["nama_lengkap"],
                'judul_seo'     => seo($_POST["nama_lengkap"]),
                'email' => $_POST["email"],
                'no_telp' => $_POST["no_telp"] ,
				'motto' 		=> $_POST["motto"] ,
                'username' => $username,
                'password' => $pass,
            
            );
            
            $db->update("tb_user", $datas , "id = '$_POST[id]' ");
			
			echo "<script>alert('Data tb_user berhasil diedit'); window.location = 'logout'</script>";
		}

	}

    elseif ($act=='update2'){

		$jdl2 				 = substr( $_POST['username'], 0, 80 );
        $tipe_file   	 	 = $_FILES['lopoFile']['type'];
        $nama_file   		 = $_FILES['lopoFile']['name'];
        $ukuran   			 = $_FILES['lopoFile']['size'];
        $tipe_file2   	 	 = seo2( $tipe_file );
        $judul_seo 		 	 = seo( $_POST['username'] );
        $acak           	 = rand( 00, 99 );
        $nama_file_unik 	 = $judul_seo.'-'.$acak.'.'.$tipe_file2;

		
		$username = $_POST['username'];
		
		if($_POST['password_lama']!=$_POST['password']){
			$pass     = md5($_POST['password']);
		}else{
			$pass     = $_POST['password_lama'];
		}


		if ( !empty( $nama_file ) ) {
		}else{
			$datas = array(
                'nama_lengkap' => $_POST["nama_lengkap"],
                'password' => $pass,
            
            );
            
            $db->update("tb_user", $datas , "id = '$_POST[id]' ");
			
			echo "<script>alert('Data User berhasil diedit'); window.location = 'user'</script>";
		}

	}

    elseif ( $act == 'remove' ) {

        $db->delete( 'tb_user', "id =  $id " );

        echo "<script>alert('$hal berhasil dihapus'); window.location = '$hal'</script>";
    }
?>
