<?php $this->layout('template', ['hal'=>'Master User']) ?>
<?php
$module = "admin";

switch($act){
  // Tampil Modul
  
  case "list":
?>

<section class="content">
    <div class="row">
        <div class="col-12">

            <button style="margin-bottom: 10px;" class="btn btn-success margin"
                onclick="window.location.href='user-add';">Tambah <?php echo $hal; ?></button> 

            <div class="card">
                <div class="card-body table-responsive">
                    <table id="my_table" class="table table-bordered table-striped w-100">
                        <thead>
                            <tr>
                                <th width="2%">No</th>
                                <th width="23%">Nama Lengkap</th>
                                <th width="30%">Username</th>
                                <!-- <th width="30%">Email</th>
                                <th width="15%">Phone</th>
                                <th width="15%">Status</th> -->
                                <th width="15%" colspan="2">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php		  
                            $no = 1;
                            foreach($tedit as $r ){
					        ?>
                            <tr>
                                <td align="center"><?php echo  $no; ?></td>
                                <td><?php echo  $r['nama_lengkap']; ?></td>
                                <td><?php echo  $r['username']; ?></td>
                                <!-- <td><?php echo  $r['email']; ?></td> -->
                                <!-- <td><?php echo  $r['no_telp']; ?></td> -->
                                <!-- <td>
                                    <?php if($r['is_verify'] == 1) : ?>
                                    <span class="badge badge-pill badge-success">Verified</span>
                                    <?php else : ?>
                                    <span class="badge badge-pill badge-danger">Pending</span>
                                    <?php endif; ?>
                                </td> -->
                                <td align="center" width="11%">
                                    <a href="user-edit-<?php echo $r['id']; ?>" class="btn btn-primary mb-2 "
                                        role="button" aria-pressed="true" data-toggle="tooltip" data-placement="top"
                                        title="Edit"> <i class="fa fa-pencil"></i> 
                                    </a>
                                    <?php if($r['level'] != 'super') : ?>
                                    <a onClick="javascript: return confirm('Data yang Sudah di Hapus TIDAK BISA Dikembalikan Kembali. Apakah Anda yakin ingin Menghapus Data Ini!!');"
                                        href="user-delete-<?php echo $r['id']; ?>" class="btn btn-danger mb-2"
                                        role="button" aria-pressed="true" data-toggle="tooltip" data-placement="top"
                                        title="Hapus"> <i class="fa fa-trash"></i> 
                                    </a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php
                                $no++;
                                }
                            ?>
                        </tbody>

                    </table>
                </div>

            </div>

        </div>
    </div>
</section>

<?php
  break;
  case "add":	
?>
<section class="content">
    <div class="row">
        <!-- left column -->
        <div class="col-md-12 ">
            <div class="card">
                <!-- general form elements -->
                <div class="card-body">
                    <!-- form start -->
                    <form id="form-setting" action="user-post" role="form" method="POST" enctype="multipart/form-data">
                        <div class="box-body table-responsive">

                            <div class="form-group">
                                <label for="exampleInputEmail1">Nama Lengkap</label>
                                <input name="nama_lengkap" type="text" class="form-control"
                                    required>
                            </div>

                            <div class="form-group">
                                <label for="exampleInputEmail1">Username</label>
                                <input name="username" type="text" class="form-control"
                                    required>
                            </div>

                            <div class="form-group">
                                <label for="exampleInputEmail1">Password</label>
                                <input name="password" type="password" class="form-control"
                                required>
                            </div>

                         
                            <!--
						<div class="form-group">
							<label>Status Admin</label>
							<select class="form-control" name="status">
								<option value="Blokir" <?php if($tedit['status']=='Blokir'){echo "selected";}?>>Blokir</option>
								<option value="Aktif" <?php if($tedit['status']=='Aktif'){echo "selected";}?>>Aktif</option>
							</select>
						</div>
						-->
                        </div><!-- /.box-body -->

                        <div class="box-footer">
                            <button id="btn-setting" type="submit" class="btn btn-primary">Simpan</button>
                        </div>
                    </form>
                </div><!-- /.box -->
            </div>
        </div>
    </div>
    </div>
</section>

<?php
    break;
	case "edit":
?>
<section class="content">
    <div class="row">
        <!-- left column -->
        <div class="col-md-12 ">
            <div class="card">
                <!-- general form elements -->
                <div class="card-body">
                    <!-- form start -->
                    <form id="form-setting" action="setting" role="form" method="POST" enctype="multipart/form-data">
                        <input type="hidden" name="id" value="<?php echo $tedit['id']; ?>">
                        <input type="hidden" name="password_lama" value="<?php echo $tedit['password']; ?>">
                        <div class="box-body table-responsive">

                            <div class="form-group">
                                <label for="exampleInputEmail1">Nama Lengkap</label>
                                <input name="nama_lengkap" type="text" class="form-control"
                                    value="<?php echo $tedit['nama_lengkap']; ?>">
                            </div>

                            <div class="form-group">
                                <label for="exampleInputEmail1">Username</label>
                                <input name="username" type="text" class="form-control"
                                    value="<?php echo $tedit['username']; ?>">
                            </div>

                            <div class="form-group">
                                <label for="exampleInputEmail1">Password</label>
                                <input name="password" type="password" class="form-control"
                                    value="<?php echo $tedit['password']; ?>">
                            </div>

                         
                            <!--
						<div class="form-group">
							<label>Status Admin</label>
							<select class="form-control" name="status">
								<option value="Blokir" <?php if($tedit['status']=='Blokir'){echo "selected";}?>>Blokir</option>
								<option value="Aktif" <?php if($tedit['status']=='Aktif'){echo "selected";}?>>Aktif</option>
							</select>
						</div>
						-->
                        </div><!-- /.box-body -->

                        <div class="box-footer">
                            <button id="btn-setting" type="submit" class="btn btn-primary">Update</button>
                        </div>
                    </form>
                </div><!-- /.box -->
            </div>
        </div>
    </div>
    </div>
</section>

<?php
    break;
	case "edit2":
?>
<section class="content">
    <div class="row">
        <!-- left column -->
        <div class="col-md-12 ">
            <div class="card">
                <!-- general form elements -->
                <div class="card-body">
                    <!-- form start -->
                    <form id="form-setting" action="setting2" role="form" method="POST" enctype="multipart/form-data">
                        <input type="hidden" name="id" value="<?php echo $tedit['id']; ?>">
                        <input type="hidden" name="password_lama" value="<?php echo $tedit['password']; ?>">
                        <div class="box-body table-responsive">

                            <div class="form-group">
                                <label for="exampleInputEmail1">Nama Lengkap</label>
                                <input name="nama_lengkap" type="text" class="form-control"
                                    value="<?php echo $tedit['nama_lengkap']; ?>">
                            </div>

                            <div class="form-group">
                                <label for="exampleInputEmail1">Username</label>
                                <input name="username" type="text" class="form-control"
                                    value="<?php echo $tedit['username']; ?>" readonly>
                            </div>

                            <div class="form-group">
                                <label for="exampleInputEmail1">Password</label>
                                <input name="password" type="password" class="form-control"
                                    value="<?php echo $tedit['password']; ?>">
                            </div>

                            <!--
						<div class="form-group">
							<label>Status Admin</label>
							<select class="form-control" name="status">
								<option value="Blokir" <?php if($tedit['status']=='Blokir'){echo "selected";}?>>Blokir</option>
								<option value="Aktif" <?php if($tedit['status']=='Aktif'){echo "selected";}?>>Aktif</option>
							</select>
						</div>
						-->
                        </div><!-- /.box-body -->

                        <div class="box-footer">
                            <button id="btn-setting" type="submit" class="btn btn-primary">Update</button>
                        </div>
                    </form>
                </div><!-- /.box -->
            </div>
        </div>
    </div>
    </div>
</section>
<?php
    break;  
}
?>