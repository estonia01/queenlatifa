<?php
use \Gumlet\ImageResize;
    // Update modul
    if ( $act == 'update' ) {

        $tgl_post = convertDate('/', $_POST['tgl']);

        if ( !empty( $nama_file ) ) {
            if ( ( $ukuran == 0 ) OR ( $ukuran == 02 ) OR ( $ukuran>9060817 ) ) {
                echo "<script>window.alert('Gagal Upload Gambar, ukuran gambar lebih dari 2 MB !'); window.location(history.back(-1))</script>";
            } else {
            }
        } else {
            try {
                $datas = array(
                    'nama_obat' => $_POST['nama_obat'],
                    'satuan' => $_POST['satuan'],
                    'stok' => $_POST['stok'],
                    'harga_beli' => formatToInt($_POST['harga_beli']),
                    'harga_jual' => formatToInt($_POST['harga_jual']),
                    'tgl_kadaluarsa' => $tgl_post
                );
                $saved = $db->update( 'tb_master_obat', $datas, "id_obat = '$_POST[id_obat]' " );

                echo "<script>alert('Data $hal berhasil diedit'); window.location = '$hal-edit-$_POST[id_obat]'</script>";
            } catch( PDOException $e ) {
                echo "<script>alert('Data $hal Gagal diedit!'); window.location = '$hal-edit-$_POST[id_obat]'</script>";
            }
        }
    }

    // add modul
    elseif (  $act == 'add' ) {
        $jdl2 				 = substr( $_POST['judul'], 0, 80 );
        $tgl_post = convertDate('/', $_POST['tgl']);
        

        // Upload Image
        try {
            $datas = array(
                'nama_obat' => $_POST['nama_obat'],
                'satuan' => $_POST['satuan'],
                'stok' => $_POST['stok'],
                'harga_beli' => formatToInt($_POST['harga_beli']),
                'harga_jual' => formatToInt($_POST['harga_jual']),
                'tgl_kadaluarsa' => $tgl_post
            );
            $saved = $db->insert( 'tb_master_obat', $datas );
            $insertId = $db->lastId();

            echo "<script>alert('Data $hal berhasil ditambah'); window.location = '$hal'</script>";

        } catch( PDOException $e ) {
            echo "<script>alert('$hal Gagal diedit!'); window.location = '$hal'</script>";
        }

    }

    // remove modul
    elseif ( $act == 'remove' ) {

        $del = $db->delete( 'tb_master_obat', "id_obat='$id'" );

        echo "<script>alert('Data $hal berhasil dihapus'); window.location = '$hal'</script>";
    }
?>
