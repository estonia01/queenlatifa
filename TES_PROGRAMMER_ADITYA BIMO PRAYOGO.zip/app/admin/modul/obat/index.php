<?php $this->layout('template', ['hal'=>'Master Obat']) ?>
<?php
	$module = "obat";

	switch($act){
		case "list":
	?>
<section class="content">
    <div class="row">
        <div class="col-md-12">
            
            <button class="btn btn-primary" onclick="window.location.href='<?php echo $module; ?>-add';"><i
                    class="fa fa-plus" aria-hidden="true"></i> Tambah Data</button>
            <div class="card" style="margin-top:10px">
                <div class="card-body ">
                    <div class="table-responsive">
                        <table id="my_table" class="table table-striped table-bordered">
                            <thead>
                                <tr>
                                    <th width="2%" class="center">No</th>
                                    <th width="30%" class="center">Nama </th>
                                    <th width="10%" class="center">Stok</th>
                                    <th width="10%" class="center">Satuan</th>
                                    <th width="10%" class="center">Harga Beli</th>
                                    <th width="10%" class="center">Harga Jual</th>
                                    <th width="15%" class="center">Tgl Kadaluarsa</th>
                                    <?php if($_SESSION['leveladmin'] == 'super') : ?>
                                    <th width="20%" class="center">Aksi</th>
                                    <?php endif; ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                            $no = 1;
                            foreach($dataku as $r){
                            ?>
                                <tr>
                                    <td align="center"><?php echo  $no; ?></td>
                                    <td><?php echo  $r['nama_obat']; ?></td>
                                    <td><?php echo  $r['stok']; ?></td>
                                    <td><?php echo  $r['satuan']; ?></td>
                                    <td>Rp <?php echo  rp($r['harga_beli']); ?></td>
                                    <td>Rp <?php echo  rp($r['harga_jual']); ?></td>
                                    <td width="20%" align="center"><?php echo  tgl2($r['tgl_kadaluarsa']); ?></td>
                                    <?php if($_SESSION['leveladmin'] == 'super') : ?>
                                    <td align="center" width="11%">
                                        <a href="<?php echo $module; ?>-edit-<?php echo $r['id_obat']; ?>"
                                            class="btn btn-warning mb-2 " role="button" aria-pressed="true"
                                            data-toggle="tooltip" data-placement="top" title="Edit"> <i
                                                class="fa fa-pencil"></i>
                                        </a>

                                        <a onClick="javascript: return confirm('Data yang Sudah di Hapus TIDAK BISA Dikembalikan Kembali. Apakah Anda yakin ingin Menghapus Data Ini!!');"
                                            href="<?php echo $module; ?>-delete-<?php echo $r['id_obat']; ?>"
                                            class="btn btn-danger mb-2" role="button" aria-pressed="true"
                                            data-toggle="tooltip" data-placement="top" title="Hapus"> <i
                                                class="fa fa-trash"></i>
                                        </a>
                                    </td>
                                    <?php endif; ?>
                                </tr>
                                <?php
						$no++;
						}
						?>
                            </tbody>
                        </table>
                    </div>
                </div><!-- /.card-body -->
            </div><!-- /.card -->
        </div><!-- /.col-md-12 -->
    </div>
</section><!-- /.section -->

<?php
		break;
		case "add":
		
		date_default_timezone_set('Asia/Jakarta');
		$tgl = date("d-m-Y");
		$skrng = date("d/m/Y");
		$time = date("H:i");
	?>
<section class="content">
    <div class="row">
        <!-- left column -->
        <div class="col-md-12 ">
            <div class="card">
                <!-- form start -->
                <form role="form" action="obat" method="POST" enctype="multipart/form-data">
                    <!-- general form elements -->
                    <div class="card-body">
                        <div class="row">
                            <!-- <div class="col-md-12">
                                <div class="form-group">
                                    <label for="">Kategori</label>
                                    <select class="form-control" name="id_kategori">
                                        <option value="">-- Pilih Kategori --</option>
                                        <?php
                                            foreach($kategori as $row) :
                                        ?>
                                        <option value="<?= $row['id_kategori'] ?>"><?= $row['judul'] ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div> -->
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Nama Obat<span title="wajib"
                                            style="color: red;">*</span></label>
                                    <input name="nama_obat" type="text" class="form-control" required>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Stok</label>
                                    <input name="stok" type="number" class="form-control" required>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Satuan</label>
                                    <input name="satuan" type="text" class="form-control" required>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Harga Beli</label>
                                    <input name="harga_beli" type="text" class="form-control ninjin" required>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Harga Jual</label>
                                    <input name="harga_jual" type="text" class="form-control ninjin" required>
                                </div>
                            </div>

                            <!-- <div class="col-md-6">
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Status </label>
                                    <select name="is_verify" class="form-control">
                                        <option value="1">Approved</option>
                                        <option value="0">Belum Terverifikasi</option>
                                    </select>
                                </div>
                            </div> -->
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Tgl Kadaluarsa</label>
                                    <div class="input-group">
                                        <span class="input-group-addon"><i
                                                class="icon ion-calendar tx-16 lh-0 op-6"></i></span>
                                        <input name='tgl' type="text" autocomplete="off" class="form-control fc-datepicker"
                                            placeholder="MM/DD/YYYY">
                                    </div>
                                </div>
                            </div>
                        </div><!-- /.box-body -->
                    </div><!-- /.card-body -->
                    <div class="card-footer pb-5">
                        <button type="submit" class="mb-2 btn btn-primary float-left">Simpan</button>
                        <input type="button" class="mb-2 btn btn-secondary float-right" value="Kembali"
                            onclick="location.href='<?php echo $module; ?>' ">
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>

<?php
		break;
		case "edit":
		$tgl 	= explode("-", $data['tgl_kadaluarsa']);
		$tgl1=$tgl[1];
		$bln=$tgl[2];
		$thn=$tgl[0];
		$tangalo = $tgl1."/".$bln."/".$thn;	
    ?>

<section class="content">
    <div class="row">
        <!-- left column -->
        <div class="col-md-12 ">
            <div class="card">
                <!-- form start -->
                <form role="form" action="obat" method="POST" enctype="multipart/form-data">
                    <input type="hidden" name="id_obat" value="<?php echo $data['id_obat'] ?>">
                    <!-- general form elements -->
                    <div class="card-body">

                        <div class="row">
                            <!-- <div class="col-md-12">
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Kategori</label>
                                    <select name="id_kategori" class="form-control" id="kategori" required>
                                        <?php foreach($kategori as $r) : ?>
                                        <option value="<?=$r['id_kategori']?>"
                                            <?php echo ($data['id_kategori'] == $r['id_kategori'])? 'selected' : '' ?>>
                                            <?=$r['judul']?></option>
                                        <?php endforeach ?>
                                    </select>
                                </div>
                            </div> -->
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Nama Obat<span title="wajib"
                                            style="color: red;">*</span></label>
                                    <input name="nama_obat" type="text" class="form-control"
                                        value="<?php echo $data['nama_obat'] ?>" required>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Stok</label>
                                    <input name="stok" type="number" class="form-control"
                                        value="<?php echo $data['stok'] ?>" required>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Satuan</label>
                                    <input name="satuan" type="text" class="form-control"
                                        value="<?php echo $data['satuan'] ?>" required>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Harga Beli</label>
                                    <input name="harga_beli" type="text" class="form-control"
                                        value="<?php echo rp($data['harga_beli']) ?>" required>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Harga Jual</label>
                                    <input name="harga_jual" type="text" class="form-control ninjin"
                                        value="<?php echo rp($data['harga_jual']) ?>" required>
                                </div>
                            </div>

                            
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Tgl Kadaluarsa</label>
                                    <div class="input-group">
                                        <span class="input-group-addon"><i
                                                class="icon ion-calendar tx-16 lh-0 op-6"></i></span>
                                        <input type="text" name="tgl" class="form-control fc-datepicker"
                                            placeholder="DD/MM/YYYY" value="<?php echo $tangalo ?>">
                                    </div>
                                </div>
                            </div>



                        </div><!-- /.box-body -->

                    </div><!-- /.card-body -->
                    <div class="card-footer pb-5">
                        <button type="submit" class="mb-2 btn btn-success float-left">Simpan</button>
                        <input type="button" class="mb-2 btn btn-secondary float-right" value="Kembali"
                            onclick="location.href='<?php echo $module; ?>' ">
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>
<?php
		break;  
	}
?>