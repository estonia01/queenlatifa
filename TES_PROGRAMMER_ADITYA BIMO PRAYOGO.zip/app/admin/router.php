<?php
/*
 * ------------------------------------------------------
 *  Router Admin
 * ------------------------------------------------------
 */

// error_reporting(E_ALL);
// ini_set('display_errors', '1');
$path = APPPATH . ADMPATH . 'modul/';

$router->get("/$_ENV[URL_LOGIN]", function () use ($login) {
    echo $login->render('login');
});

$router->post("/$_ENV[URL_LOGIN]", function () use ($login, $jmw, $db) {
    $username = $_POST['username'];
    $pass = md5($_POST['password']);
    $login = $db->read("tb_user", "*", "username='$username' AND password='$pass' AND status='Aktif'")->fetch();
    $ketemu = $db->read("tb_user", "COUNT(*)", "username='$username' AND password='$pass' AND status='Aktif'")->fetchColumn();
    $r = $login;
    if ($ketemu > 0) {
        $_SESSION['nama_admin']         = $r['username'];
        $_SESSION['email_admin']        = $r['email'];
        $_SESSION['namalengkapadmin']   = $r['nama_lengkap'];
        $_SESSION['passadmin']          = $r['password'];
        $_SESSION['leveladmin']         = $r['level'];
        $_SESSION['id_admin']           = $r['id'];
        $_SESSION['idsession']          = $r['id_session'];
        $_SESSION['fotoku']             = $r['gambar'];
        $_SESSION['halaman']            = 'Home';
        $_SESSION['IsAuthorized']       = true;
        session_name("Z6IBd5Xemw");
        
        header("location: ../$_ENV[URL_ADMIN]/obat");
    } else {
        header("location: ../$_ENV[URL_LOGIN]");
    }
});

/** Cek Keamanan **/
$router->before('GET|POST', "/$_ENV[URL_ADMIN]/.*", function () {
    if (!isset($_SESSION['nama_admin'])) {
            $getWholeUrl = "http://" . $_SERVER['HTTP_HOST'] . "" . $_SERVER['REQUEST_URI'] . "";
            if (substr($getWholeUrl, -1) == '/') {
                header("location: ../$_ENV[URL_LOGIN]");
            } else {
                header("location: ../$_ENV[URL_LOGIN]");
            }
        exit();
    } 
});



/** Router dalam folder Admin **/
$router->mount("/$_ENV[URL_ADMIN]", function () use ($router, $db, $jmw, $path,$msg) {

    /** Security Lvl 2 **/
    $router->get('/', function () {
        if (!isset($_SESSION['nama_admin'])) {
            header("location: $_ENV[URL_LOGIN]");
            exit();
        } else {
            $getWholeUrl = "http://" . $_SERVER['HTTP_HOST'] . "" . $_SERVER['REQUEST_URI'] . "";
            if (substr($getWholeUrl, -1) == '/') {
                header('location: obat');
            } else {
                header('location: ' . ADMPATH . 'obat');
            }

        }

    });

    /** Logout **/
    $router->get('/logout', function () use ($jmw, $db, $path) {
        session_start();
        session_destroy();
        header("location: ../$_ENV[URL_LOGIN]");
    });

    /** Url Setting **/
    $router->get('/setting', function () use ($jmw, $db, $path) {
        $data = $db->connection("SELECT * FROM tb_user WHERE id = $_SESSION[id_admin] ")->fetch();
        echo $jmw->render('modul/admin/index', ['act' => 'edit', 'tedit' => $data]);
    });

    $router->get('/user', function () use ($jmw, $db, $path) {
        if($_SESSION['leveladmin'] != 'super'){
            echo "<script>alert('Anda tidak memiliki hak akses halaman ini !'); window.location(history.back(-1))</script>";
            exit;
        }
        $data = $db->connection("SELECT * FROM tb_user ")->fetchAll();
        echo $jmw->render('modul/admin/index', ['act' => 'list', 'tedit' => $data,'hal' => 'user']);
    });

    $router->get('/user-add', function () use ($jmw, $db) {
        echo $jmw->render('modul/admin/index', ['act' => 'add']);
    });

    $router->get('/user-edit-(\d+)', function ($id) use ($jmw, $db,$path) {
        if($_SESSION['leveladmin'] != 'super'){
            echo "<script>alert('Anda tidak memiliki hak akses halaman ini !'); window.location(history.back(-1))</script>";
            exit;
        }
        $edit = $db->connection("SELECT * FROM tb_user WHERE id= $id ")->fetch();
        echo $jmw->render('modul/admin/index', ['act' => 'edit2', 'tedit' => $edit]);
    });

    $router->post('/setting2', function () use ($jmw, $db, $path) {
        $act = "update2";
        $hal = "setting";
        include ($path . 'admin/aksi.php');
    });

    $router->post('/user-post', function () use ($jmw, $db, $path) {
        $act = "add";
        $hal = "user";
        include ($path . 'admin/aksi.php');
    });

    $router->get('/user-delete-(\d+)', function ($id) use ($jmw, $db, $path,$msg) {
        if($_SESSION['leveladmin'] != 'super'){
            echo "<script>alert('Anda tidak memiliki hak akses halaman ini !'); window.location(history.back(-1))</script>";
            exit;
        }
        $act = "remove";
        $hal = "user";
        include ($path . 'admin/aksi.php');
    });
    

    /** Setting Updated **/
    $router->post('/setting', function () use ($jmw, $db, $path) {
        $act = "update";
        $hal = "setting";
        include ($path . 'admin/aksi.php');
    });
     
/*
 * ------------------------------------------------------
 *  Router obat
 * ------------------------------------------------------
 */

    /** Url obat **/
    $router->get('/obat', function () use ($jmw, $db) {
        $dataku = $db->connection("SELECT * FROM tb_master_obat ")->fetchAll();
        echo $jmw->render('modul/obat/index', ['act' => 'list', 'dataku' => $dataku]);
    });

    /** Show Add Form obat **/
    $router->get('/obat-add', function () use ($jmw, $db) {
        echo $jmw->render('modul/obat/index', ['act' => 'add']);
    });

    /** Show Edit Form obat **/
    $router->get('/obat-edit-(\d+)', function ($id) use ($jmw, $db) {

        if($_SESSION['leveladmin'] != 'super'){
            echo "<script>alert('Anda tidak memiliki hak akses halaman ini !'); window.location(history.back(-1))</script>";
            exit;
        }
        $data = $db->connection("SELECT * FROM tb_master_obat WHERE id_obat = $id ")->fetch();
        echo $jmw->render('modul/obat/index', ['act' => 'edit', 'data' => $data]);
    });

    /** Update dan Add obat  **/
    $router->post('/obat', function () use ($jmw, $db, $path,$msg) {
        if (isset($_POST['id_obat'])) {
            $act = "update";
        } else {
            $act = "add";
        }
        $hal = "obat";
        include ($path . 'obat/aksi.php');
    });

    /** Delete obat **/
    $router->get('/obat-delete-(\d+)', function ($id) use ($jmw, $db, $path,$msg) {
        if($_SESSION['leveladmin'] != 'super'){
            echo "<script>alert('Anda tidak memiliki hak akses halaman ini !'); window.location(history.back(-1))</script>";
            exit;
        }
        $act = "remove";
        $hal = "obat";
        include ($path . 'obat/aksi.php');
    });





});


