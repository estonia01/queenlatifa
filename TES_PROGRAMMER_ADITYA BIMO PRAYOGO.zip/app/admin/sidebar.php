<!-- ============================================================== -->
<!-- Left Sidebar - style you can find in sidebar.scss  -->
<!-- ============================================================== -->
<aside class="left-sidebar">
    <!-- Sidebar scroll-->
    <div class="scroll-sidebar">
        <!-- Sidebar navigation-->
        <nav class="sidebar-nav">
            <ul id="sidebarnav">


                <li class="nav-small-cap">
                    <i class="sl-icon-options"></i>
                    <span class="hide-menu">Apps</span>
                </li>

                <li class="sidebar-item">
                    <a href="obat" class="sidebar-link">
                        <i class="sl-icon-drop"></i>
                        <span class="hide-menu">Master Obat</span>
                    </a>
                </li>
                <?php if($_SESSION['leveladmin'] == 'super') : ?>
                <li class="sidebar-item">
                    <a class="sidebar-link waves-effect waves-dark sidebar-link" href="user" aria-expanded="false">
                        <i class="sl-icon-people"></i>
                        <span class="hide-menu">User</span>
                    </a>
                </li>
                <?php endif ?>
                <li class="sidebar-item">
                    <a class="sidebar-link waves-effect waves-dark sidebar-link" href="logout" aria-expanded="false">
                        <i class="sl-icon-power"></i>
                        <span class="hide-menu">Log Out</span>
                    </a>
                </li>
            </ul>
        </nav>
        <!-- End Sidebar navigation -->
    </div>
    <!-- End Sidebar scroll-->
</aside>
