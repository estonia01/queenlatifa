<?php
// Check if the request is made using HTTPS or HTTP
$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https://' : 'http://';

// Get the server's hostname (domain)
$host = $_SERVER['HTTP_HOST'];

// Get the base directory, where your PHP script is located
$directory = str_replace(basename($_SERVER['SCRIPT_NAME']), '', $_SERVER['SCRIPT_NAME']);

// Combine the components to create the base URL
$base_url = $protocol . $host . $directory;

// You can optionally append a trailing slash for consistency
if (substr($base_url, -1) !== '/') {
    $base_url .= '/';
}

?>
