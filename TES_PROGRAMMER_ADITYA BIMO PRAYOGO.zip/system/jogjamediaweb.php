<?php
defined('BASEPATH') OR exit('No direct script access allowed');
ob_start();
session_name("CAKEPHP");
session_start();

// Load our autoloader & database
require_once BASEPATH.'database.php';

//Load helpers
require_once BASEPATH.'helper_base.php';
require_once BASEPATH.'helper_paging.php';
require_once BASEPATH.'helper_csrf.php';
require_once BASEPATH.'fungsi_umum.php';
require_once BASEPATH.'fungsi_thumb.php';
require_once BASEPATH.'ImgCompressor.php';
require_once BASEPATH.'helper_webp.php';
require_once BASEPATH.'flash_message.php';


// Security for Form POST
$csrf = new CSRF();

// Instantiate the class Flash Message
$msg = new \Plasticbrain\FlashMessages\FlashMessages();

// Error Display
$whoops = new \Whoops\Run;
$whoops->pushHandler(new \Whoops\Handler\PrettyPageHandler);
//$whoops->register();

$filename = __DIR__ . preg_replace('#(\?.*)$#', '', $_SERVER['REQUEST_URI']);
if (php_sapi_name() === 'cli-server' && is_file($filename)) {
    return false;
}

// Create Router instance
$router = new \Bramus\Router\Router();

// Before Router Middleware
$router->before('GET', '/.*', function () {
    header('X-Powered-By: bramus/router');
});

// Create new Plates instance
$jmw       = new League\Plates\Engine(APPPATH.'admin');
$login     = new League\Plates\Engine(APPPATH.'admin/login');


$data = array('db' => $db);
$jmw->addData($data);
$login->addData($data);
$jmw->addData(['seo' => '', 'msg' => $msg]);



