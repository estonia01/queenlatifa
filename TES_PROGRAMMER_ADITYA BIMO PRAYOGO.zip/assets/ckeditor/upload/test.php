<?php
$directory = "/home/updatejo/public_html"; // Replace with the actual path to the directory

// Check if the directory exists
if (is_dir($directory)) {
    $dirContents = scandir($directory);

    // Remove "." and ".." entries from the list
    $filteredContents = array_diff($dirContents, ['.', '..']);

    // Print the list of folders and files
    foreach ($filteredContents as $item) {
        echo $item . "<br>";
    }
} else {
    echo "Directory does not exist.";
}