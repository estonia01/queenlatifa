<?php
error_reporting(0);
ini_set('memory_limit', '256M');

// error_reporting(E_ALL);
// ini_set('display_errors', '1');

$application_folder = 'app';
$system_path = 'system';
$admin_folder = 'admin';

if (($_temp = realpath($system_path)) !== FALSE)
{
    $system_path = $_temp.DIRECTORY_SEPARATOR;
}

// Path to the system directory
define('APPPATH', $application_folder.DIRECTORY_SEPARATOR);
define('BASEPATH', $system_path);
define('ADMPATH', $admin_folder.DIRECTORY_SEPARATOR);

require_once __DIR__.'/vendor/autoload.php';
$dotenv = Dotenv\Dotenv::createImmutable(__DIR__);
$dotenv->load();
require_once BASEPATH.'jogjamediaweb.php';

// Custom 404 Handler
// $router->set404(function () use ($base_url) {
//         header('location:  '.$base_url.'404');
// });


/*
 * ------------------------------------------------------
 *  Router Front End
 * ------------------------------------------------------
 */

$router->get('/', function () use ($db,$base_url) {

    header('location:  '.$base_url.'admin');

});

$router->get('/users', function () use ($db,$base_url) {
    $users = $db->connection("SELECT * FROM tb_user")->fetchAll();
    

    // Encode data ke JSON untuk digunakan di tabel
    echo json_encode([
        'status' => 'success',
        'data' => $users
    ]);
});

$router->get('/obat', function () use ($db,$base_url) {
    $obats = $db->connection("SELECT * FROM tb_master_obat")->fetchAll();
    

    // Encode data ke JSON untuk digunakan di tabel
    echo json_encode([
        'status' => 'success',
        'data' => $obats
    ]);
});



/*
 * ------------------------------------------------------
 *  Router Admin
 * ------------------------------------------------------
 */
include(APPPATH.'admin/router.php');

$router->run();